import java.util.Scanner
import scala.util.{Failure, Success, Try}
import java.net.{HttpURLConnection, URL}
import java.io.{File, PrintWriter}
import scala.io.Source
import play.api.libs.json._
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.time.{LocalDateTime, OffsetDateTime, ZoneOffset, ZonedDateTime, ZoneId, LocalDate}
import play.api.libs.json._
import scala.collection.mutable.ListBuffer
import java.time
import java.text.SimpleDateFormat
//111
object CSVReaderApp extends App {

//  ---
  val scanner = new Scanner(System.in)
  val apiKey = "4d6d23aded204adcbfc6db5a456a6c62"
  val datasetIds = Map(181 -> "wind3min.csv", 188 -> "solar3min.csv", 191 -> "hydro3min.csv")
//  ---

  // 文件路径定义
  val hydroFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\hydro3min.csv"
  val windFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\wind3min.csv"
  val solarFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\solar3min.csv"
  val dataManager = new EnergyDataManager(hydroFilename, windFilename, solarFilename)
//  用于判断时间
  val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  val cutoffDate = LocalDateTime.parse("2014-01-01T00:00:00.000Z", formatter)
  val today = ZonedDateTime.now(java.time.ZoneOffset.UTC)
  val formattedNow = today.format(formatter)
  val nowDateTime = LocalDateTime.parse(formattedNow, formatter)  // 将formattedNow字符串转换回LocalDateTime以便比较
  val dateTimePattern = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z".r

  // 定义全局变量
  var globalStartDate: String = ""
  var globalEndDate: String = ""

  // 查询处理
  def handleQuery(dataType: String, filename: String): Unit = {
    var validDateEntered = false
//    var userInput_1 = ''
    println(s"\n$dataType Data Query")
//    val range = dataManager.getDateRange(filename)
//    println(s"Data available from ${range._1.getOrElse("unknown")} to ${range._2.getOrElse("unknown")}")
    while (!validDateEntered) {
      println("Enter the date and time in the format yyyy-MM-dd'T'HH:mm:ss.SSS'Z' or press '0' to exit:")
      val userInputDate = scanner.nextLine()
      // Check if user wants to exit
      if (userInputDate == "0") {
        return // Exit the function
      }

      // Check the validity of the date
      if (checkDate(userInputDate)) {
        validDateEntered = true // Set to true to break the loop if date is valid
  //    val userInput = LocalDateTime.parse(userInputDate, formatter)
        Try(dataManager.dateFormat.parse(userInputDate).getTime) match {
          case Success(timestamp) =>
            dataManager.findDataByType(filename, timestamp) match {
              case Some(value) => println(s"$dataType energy at specified time: $value")
              case None => println(s"No $dataType data found at specified time.")
            }
          case Failure(_) =>
            println("Invalid date format or unable to parse date. Please use the format yyyy-MM-dd'T'HH:mm:ss.SSS'Z'.")
            validDateEntered = false // Ensure loop continues if there's a parse failure
        }
      } else {
        println("Invalid date format. Please use the correct format and try again.")
      }
    }
  }
  def check2Date(date: String, date2: String):Boolean = {
    var isCompleted: Boolean = false
    if (dateTimePattern.matches(date)&&dateTimePattern.matches(date2)) {
      val DateTest = LocalDateTime.parse(date, formatter)
      val Date2Test = LocalDateTime.parse(date2, formatter)
      if (Date2Test.isAfter(DateTest)){
        isCompleted = true
      }else{
        isCompleted = false
        print("Your end time should be greater than your start time.\n")
      }
    //      println(DateTest)
    //      println(Date2Test)
    //      println("看到这个代码说明checkDate2被运行")
  }else{
    isCompleted = false
    println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  }
    isCompleted
  }
  def checkDate(date: String): Boolean = {
    var isCompleted: Boolean = false
    if (dateTimePattern.matches(date)) {
      val DateTest = LocalDateTime.parse(date, formatter)
      val startDate = LocalDateTime.parse(globalStartDate, formatter)
      val endDate = LocalDateTime.parse(globalEndDate, formatter)
//      println(startDate)
//      println(endDate)
//      println("看到这个代码说明checkDate被运行")
      if (!DateTest.isBefore(startDate) && !DateTest.isAfter(endDate)) {
        isCompleted = true
//        println(DateTest+"在"+startDate+"和"+endDate+"之间")
      }else{
        isCompleted = false
        println("Your " + DateTest + " should be between " + startDate + " and " + endDate)
      }
    }else{
      isCompleted = false
      println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    }
    isCompleted
  }

  def mainMenu(): Unit = {
    println("\nSelect the type of data to query or action to perform:")
    println("1. Solar Data")
    println("2. Hydro Data")
    println("3. Wind Data")
    println("4. Collect and Store Data")
    println("5. Analyze Solar Data")
    println("6. Analyze Hydro Data")
    println("7. Analyze Wind Data")
    println("8. Fetch Solar Data for a Range and Sort")
    println("9. Fetch Hydro Data for a Range and Sort")
    println("10. Fetch Wind Data for a Range and Sort")
    println("11. Generate Pie Chart of Total Energy")
    println("12. Check existing data for bugs.")
    println("13. Add or Delete Solar Data")
    println("14. Add or Delete Hydro Data")
    println("15. Add or Delete Wind Data")
    println("0. Exit")
    println("Enter your choice (0-15):")
  }

  def handleDataCollection(): Unit = {
    println("\nCollecting and storing energy data...")
    dataManager.collectAndStoreData()
  }
  def handleAnalysis(dataType: String, filename: String): Unit = {
    println(s"\nAnalyzing $dataType Data...")
    dataManager.analyzeData(filename)
  }


  def handleRangeQuery(dataType: String, filename: String): Unit = {
    var start = false
    var end = false
    while (!start && !end) {
      println(s"\nEnter the start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
      val startTimeString = scanner.nextLine()
      println("Enter the end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
      val endTimeString = scanner.nextLine()
      // Check if user wants to exit
      if (startTimeString == "0" || endTimeString == "0") {
        return // Exit the function
      }

      if (checkDate(startTimeString) && checkDate(endTimeString)) {
        start = true
        end = true
        val data = dataManager.fetchDataInRange(filename, startTimeString, endTimeString)
        println(s"\nDo you want to sort the data by the value. (Y/N)?")
        val shouldSort = scanner.nextLine().toUpperCase
        dataManager.printData(data, shouldSort == "Y")
      }else if(checkDate(startTimeString) && !checkDate(endTimeString)){
        println("There is a problem with your end time input.")
      }else if(!checkDate(startTimeString) && checkDate(endTimeString)){
        println("There is a problem with your start time input.")
      } else{
        val startDate = LocalDateTime.parse(startTimeString, formatter)
        val endDate = LocalDateTime.parse(endTimeString, formatter)
        if(endDate.isBefore(startDate)){
          println("Your end time is earlier than your start time.")
        }else{
          println("something wrong.")
        }
      }
    }
  }

  def withFileSource[T](filename: String)(f: Iterator[String] => T): T = {
    val src = Source.fromFile(filename)
    try {
      f(src.getLines())
    } finally {
      src.close()
    }
  }

  def showAllData(): Unit = {
    val fileNames = List(hydroFilename, windFilename, solarFilename)
    var totalEnergy = 0.0
    val energies = scala.collection.mutable.Map[String, Double]()

    fileNames.foreach { filename =>
      withFileSource(filename) { lines =>
        val header = lines.next()
        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime")
        val endTimeIndex = header.split(",").indexWhere(_.trim == "endTime")
        val valueIndex = header.split(",").indexWhere(_.trim == "value")
        val energyData = lines.map { line =>
          val parts = line.split(",")
          (parts(startTimeIndex), parts(endTimeIndex), parts(valueIndex).toDouble)
        }.toList

        val dates = energyData.map(_._1) ++ energyData.map(_._2)
        val minDate = dates.min
        val maxDate = dates.max
        val total = energyData.map(_._3).sum

        println(s"${filename.split("\\\\").last}:")
        println(s"Data range: $minDate to $maxDate")
        println(s"Total Energy: $total kWh")

        energies(filename.split("\\\\").last) = total
        totalEnergy += total
      }
    }

    println(s"\nTotal Energy from all sources: $totalEnergy kWh")
    energies.foreach { case (source, energy) =>
      val percentage = (energy / totalEnergy) * 100
      println(s"Percentage of $source: $percentage%")
    }
  }

  def findFaults(): Unit = {
    val fileNames = Map("Hydro" -> hydroFilename, "Wind" -> windFilename, "Solar" -> solarFilename)
    val dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("UTC"))
    var faultFound = false

    fileNames.foreach { case (energyType, filename) =>
      withFileSource(filename) { lines =>
        val header = lines.next()
        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime")
        val valueIndex = header.split(",").indexWhere(_.trim == "value")
        val values = lines.map { line =>
          val parts = line.split(",")
          (ZonedDateTime.parse(parts(startTimeIndex), dateTimeFormatter), parts(valueIndex).toDouble)
        }.toList

        // Filtering out night time data for Solar energy only
        val filteredValues = if (energyType == "Solar") {
          values.filter { case (date, _) =>
            val hour = date.getHour
            !(hour >= 20 || hour < 8) // Exclude 20:00 to 08:00 for solar data
          }
        } else values

        val totalCount = filteredValues.length
        val lowValuesCount = filteredValues.count(_._2 < 100)
        val veryLowValuesCount = filteredValues.count(_._2 < 500)

        // Checking for faults based on thresholds
        if (lowValuesCount.toDouble / totalCount >= 0.2) {
          println(s"$energyType energy may have data faults. $lowValuesCount out of $totalCount readings are below 100.")
          faultFound = true
        }
        if (veryLowValuesCount.toDouble / totalCount >= 0.5) {
          println(s"$energyType energy may have low energy output. $veryLowValuesCount out of $totalCount readings are below 500.")
          faultFound = true
        }
      }
    }

    if (!faultFound) {
      println("No faults found.")
    }
  }

  def fetchData(url: String, apiKey: String): String = {
    val connection = new URL(url).openConnection().asInstanceOf[HttpURLConnection]
    connection.setRequestMethod("GET")
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("x-api-key", apiKey)

    val responseCode = connection.getResponseCode
    if (responseCode == HttpURLConnection.HTTP_OK) {
      val inputStream = connection.getInputStream
      val content = Source.fromInputStream(inputStream).mkString
      inputStream.close()
      content
    } else {
      throw new RuntimeException(responseCode.toString)
    }
  }

  def extractCsvFromJson(jsonData: String): String = {
    val json = Json.parse(jsonData)
    (json \ "data").as[String] // Directly extract CSV data
  }

  def saveDataToFile(data: String, fileName: String): Unit = {
    val path = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\" + fileName // 设定文件的存储路径
    val file = new File(path)
    val writer = new PrintWriter(file)
    writer.write(data)
    writer.close()
//    println(s"Data saved to $path")
  }

  def fetchDataAndSave(startTimeString: String, endTimeString: String): Either[String, Unit] = {
    var errorCodes = "200"  // 初始化为字符串"200"，表示成功
    try {
      datasetIds.foreach { case (datasetId, fileName) =>
        val url = s"https://data.fingrid.fi/api/datasets/$datasetId/data?startTime=$startTimeString&endTime=$endTimeString&pageSize=20000&format=csv"
//        println(s"Fetching data for dataset ID $datasetId")
        val rawData = fetchData(url, apiKey)
//        println("Data fetched successfully:")
        val csvData = extractCsvFromJson(rawData)
        saveDataToFile(csvData, fileName)
      }
      Right(())  // 成功时返回Right，没有错误码
    } catch {
      case e: Exception =>
        errorCodes = e.getMessage  // 出错时更新errorCodes
        println(errorCodes)
        Left(errorCodes)  // 返回Left，包含错误消息

    }
  }

  def deleteAdd(dataType: String, filename: String): Unit = {
    println(s"\nHandling $dataType Data")
    val scanner = new Scanner(System.in)

    println("Choose action: 1 for Add, 2 for Delete")
    val action = scanner.nextLine()

    println("Enter start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
    val startTime = scanner.nextLine()
    println("Enter end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
    val endTime = scanner.nextLine()


    if (!check2Date(startTime,endTime)) {
      println("Invalid date format or date range. Please try again.")
      deleteAdd(dataType, filename) // execute for side effects without returning
      return // early exit for clarity, if needed
    }

    action match {
      case "1" => // Add data
        println("Enter value:")
        val value = scanner.nextLine().toDouble // Assume value is a double
        if (dataType == "Solar"){
          val ID = 188
          addData(ID, startTime, endTime, value, filename)
        }else if(dataType == "Hydro"){
          val ID = 191
          addData(ID, startTime, endTime, value, filename)
        }else if(dataType == "Wind"){
          val ID = 181
          addData(ID, startTime, endTime, value, filename)
        }else{
          println("add_delete的文件名出现错误。")
        }
      //        addData(startTime, endTime, value, filename)
      case "2" => // Delete data
        deleteData(startTime, endTime, filename)
      case _ =>
        println("Invalid action chosen.")
    }
  }
  def addData(datasetId:Int, startTime: String, endTime: String, value: Double, filename: String): Unit = {
    val newData = s"$datasetId,$startTime,$endTime,$value"
    val file = new File(filename)
    val lines = Source.fromFile(file).getLines.toList
    val updatedLines = lines :+ newData // Add new data line to the end
    writeToFile(updatedLines, filename)
  }

  def deleteData(startTime: String, endTime: String, filename: String): Unit = {
    val file = new File(filename)
    val lines = Source.fromFile(file).getLines.toList
    val header = lines.head  // 保留标题行
    val dataLines = lines.tail  // 移除标题行，仅处理数据行

    val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    val startTimestamp = dateFormat.parse(startTime).getTime
    val endTimestamp = dateFormat.parse(endTime).getTime

    val updatedLines = header +: dataLines.filterNot { line =>
      val parts = line.split(",")
      val lineStartTimestamp = dateFormat.parse(parts(1)).getTime  // 假设开始时间在第二列
      val lineEndTimestamp = dateFormat.parse(parts(2)).getTime  // 假设结束时间在第三列
      lineStartTimestamp >= startTimestamp && lineEndTimestamp <= endTimestamp
    }
    writeToFile(updatedLines, filename)
  }


  def writeToFile(lines: List[String], filename: String): Unit = {
    val pw = new PrintWriter(new File(filename))
    lines.foreach(pw.println)
    pw.close()
  }

  def run(): Unit = {

    var continue_1 = true
    var a = 0

    while (a != 200) {
      println("Enter the start date (yyyy-MM-dd):")
      val startDateInput = scanner.nextLine()
      println("Enter the start time (HH:mm:ss.SSS):")
      val startTimeInput = scanner.nextLine()
      val startTimeString = startDateInput + 'T' + startTimeInput + 'Z'


      println("Enter the end date (yyyy-MM-dd):")
      val endDateInput = scanner.nextLine()
      println("Enter the end time (HH:mm:ss.SSS):")
      val endTimeInput = scanner.nextLine()
      val endTimeString = endDateInput + 'T' + endTimeInput + 'Z'


      if (dateTimePattern.matches(startTimeString) && dateTimePattern.matches(endTimeString)) {
        val startDate = LocalDateTime.parse(startTimeString, formatter)
        val endDate = LocalDateTime.parse(endTimeString, formatter)
        globalStartDate = startTimeString
//        println(globalStartDate)
        globalEndDate = endTimeString
        val result = fetchDataAndSave(startTimeString, endTimeString)
        result match {
          case Right(_) =>
            if (startDate.isBefore(cutoffDate)) {
              println("The start date cannot be earlier than 2014-01-01T00:00:00.000Z.")
              a = 0
            }else if(nowDateTime.isBefore(endDate)){
              println("The end date must be no later than today's date.")
              a = 0
            } else {
              println("Operation successful.")
              a = 200  // 设置 a 为 200 表示成功，终止循环
            }
          case Left(errorCode) =>
            a = Try(errorCode.toInt).getOrElse(0)  // 尝试将 errorCode 转换为 Int，如果失败则设置 a 为 0
            //          println(a)
            if (a == 422) {
              println("There is an error in the format of time.") // 输出变量a的值
              if(endDate.isBefore(startDate)){
                println("Your end time is earlier than your start time.")
              }
            }else if(a == 429){
              println("Rate limit is exceeded. Try again in 60 seconds.")
            }else if(a == 403){
              println("Out of call volume quota. Quota will be replenished in 23:59:59.")
            }else{
              println("There is an unknown error, please try again")
            }
        }
      } else {
        println("One or both date strings are incorrectly formatted.")
        a = 0
      }
    }


//    ---
    while (continue_1) {
      mainMenu()
      val choice = scanner.nextLine()
      choice match {
        case "1" => handleQuery("Solar", solarFilename)
        case "2" => handleQuery("Hydro", hydroFilename)
        case "3" => handleQuery("Wind", windFilename)
        case "4" => handleDataCollection()
        case "5" => handleAnalysis("Solar", solarFilename)
        case "6" => handleAnalysis("Hydro", hydroFilename)
        case "7" => handleAnalysis("Wind", windFilename)
        case "8" => handleRangeQuery("Solar", solarFilename)
        case "9" => handleRangeQuery("Hydro", hydroFilename)
        case "10" => handleRangeQuery("Wind", windFilename)
        case "11" => showAllData()
        case "12" => findFaults()
        case "13" => deleteAdd("Solar", solarFilename)
        case "14" => deleteAdd("Hydro", hydroFilename)
        case "15" => deleteAdd("Wind", windFilename)
        case "0" => continue_1 = false
        case _ => println("Invalid choice. Please enter a number between 0 and 15.")
      }
    }
    println("Exiting the program.")
  }
  run() // 启动程序
}

