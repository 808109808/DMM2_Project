//def checkDate(date: String): Boolean = {
//  var isCompleted: Boolean = false
//  if (dateTimePattern.matches(date)) {
//    val DateTest = LocalDateTime.parse(date, formatter)
//    val startDate = LocalDateTime.parse(globalStartDate, formatter)
//    val endDate = LocalDateTime.parse(globalEndDate, formatter)
//    //      println(startDate)
//    //      println(endDate)
//    //      println("看到这个代码说明checkDate被运行")
//    if (!DateTest.isBefore(startDate) && !DateTest.isAfter(endDate)) {
//      isCompleted = true
//      //        println(DateTest+"在"+startDate+"和"+endDate+"之间")
//    }else{
//      isCompleted = false
//      println("Your " + DateTest + " should be between " + startDate + " and " + endDate)
//    }
//  }else{
//    isCompleted = false
//    println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
//  }
//  isCompleted
//}